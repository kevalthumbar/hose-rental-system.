# House-Rental-System
This is the project done using PHP, HTML, CSS, JavaScript, Bootstrap, MySQL, XAMPP, etc.
